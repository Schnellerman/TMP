//! Модель: trust boundaries (TB), компоненты (DE), потоки данных (DF).
//! ID формата TB01 / DE01 / DF01, номера никогда не переиспользуются.

use crate::doc::Doc;
use serde::{Deserialize, Serialize};
use std::collections::BTreeSet;

pub const PALETTE: [&str; 6] = ["#8A96A3", "#4A7FD6", "#7B4FA6", "#2F8F6B", "#D08A2E", "#B5485B"];
pub const LINE_COLOR: &str = "#F19C99";

// ---------- типы ----------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ElementKind {
    User,
    External,
    Frontend,
    Backend,
    Database,
    Queue,
    Storage,
    Other,
}

impl ElementKind {
    pub const ALL: [ElementKind; 8] = [
        ElementKind::User,
        ElementKind::External,
        ElementKind::Frontend,
        ElementKind::Backend,
        ElementKind::Database,
        ElementKind::Queue,
        ElementKind::Storage,
        ElementKind::Other,
    ];

    pub fn code(self) -> &'static str {
        match self {
            ElementKind::User => "user",
            ElementKind::External => "external",
            ElementKind::Frontend => "frontend",
            ElementKind::Backend => "backend",
            ElementKind::Database => "database",
            ElementKind::Queue => "queue",
            ElementKind::Storage => "storage",
            ElementKind::Other => "other",
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            ElementKind::User => "Пользователь / роль",
            ElementKind::External => "Внешняя система",
            ElementKind::Frontend => "Frontend",
            ElementKind::Backend => "Backend / API / сервис",
            ElementKind::Database => "База данных",
            ElementKind::Queue => "Очередь / брокер / кэш",
            ElementKind::Storage => "Файловое / объектное хранилище",
            ElementKind::Other => "Другое",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|k| k.code() == s.trim())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BoundaryStyle {
    /// Одна рамка вокруг всего содержимого (AWS, EKS, External).
    #[default]
    Zone,
    /// Отдельная рамка вокруг каждого компонента (Docker, под).
    Wrapper,
    /// Пунктирная линия поперёк потоков (Internet).
    Line,
}

impl BoundaryStyle {
    pub const ALL: [BoundaryStyle; 3] = [BoundaryStyle::Zone, BoundaryStyle::Wrapper, BoundaryStyle::Line];

    pub fn code(self) -> &'static str {
        match self {
            BoundaryStyle::Zone => "zone",
            BoundaryStyle::Wrapper => "wrapper",
            BoundaryStyle::Line => "line",
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            BoundaryStyle::Zone => "Зона: одна рамка",
            BoundaryStyle::Wrapper => "Обёртка каждого компонента",
            BoundaryStyle::Line => "Линия: сеть между зонами",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|k| k.code() == s.trim())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Boundary {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub style: BoundaryStyle,
    /// "#RRGGBB" или пусто (без заливки).
    #[serde(default)]
    pub color: String,
    #[serde(default)]
    pub parent: Option<String>,
    #[serde(default)]
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Element {
    pub id: String,
    pub name: String,
    pub kind: ElementKind,
    #[serde(default)]
    pub tech: String,
    #[serde(default)]
    pub boundary: Option<String>,
    #[serde(default)]
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Flow {
    pub id: String,
    pub from: String,
    pub to: String,
    /// Назначение потока: "Login", "Get Token".
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub data: Option<String>,
    #[serde(default)]
    pub protocol: Option<String>,
    #[serde(default)]
    pub auth: Option<String>,
    /// Граница-линия, через которую идёт поток (например, Internet).
    #[serde(default)]
    pub via: Option<String>,
    #[serde(default)]
    pub notes: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct Counters {
    #[serde(default)]
    pub de: u32,
    #[serde(default)]
    pub df: u32,
    #[serde(default)]
    pub tb: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Project {
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub created_at: u64,
    #[serde(default)]
    pub updated_at: u64,
    #[serde(default)]
    pub boundaries: Vec<Boundary>,
    #[serde(default)]
    pub elements: Vec<Element>,
    #[serde(default)]
    pub flows: Vec<Flow>,
    #[serde(default)]
    pub counters: Counters,
    #[serde(default)]
    pub doc: Doc,
}

// ---------- входные данные ----------

#[derive(Debug, Default, Deserialize)]
pub struct BoundaryInput {
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub style: String,
    #[serde(default)]
    pub color: String,
    #[serde(default)]
    pub parent: String,
    #[serde(default)]
    pub description: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct ElementInput {
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub kind: String,
    #[serde(default)]
    pub tech: String,
    #[serde(default)]
    pub boundary: String,
    #[serde(default)]
    pub description: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct FlowInput {
    #[serde(default)]
    pub from: String,
    #[serde(default)]
    pub to: String,
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub data: String,
    #[serde(default)]
    pub protocol: String,
    #[serde(default)]
    pub auth: String,
    #[serde(default)]
    pub via: String,
    #[serde(default)]
    pub notes: String,
}

#[derive(Debug, Default, Deserialize)]
pub struct BoundaryPatch {
    pub name: Option<String>,
    pub style: Option<String>,
    pub color: Option<String>,
    pub parent: Option<String>,
    pub description: Option<String>,
}

#[derive(Debug, Default, Deserialize)]
pub struct ElementPatch {
    pub name: Option<String>,
    pub kind: Option<String>,
    pub tech: Option<String>,
    pub boundary: Option<String>,
    pub description: Option<String>,
}

#[derive(Debug, Default, Deserialize)]
pub struct FlowPatch {
    pub from: Option<String>,
    pub to: Option<String>,
    pub title: Option<String>,
    pub data: Option<String>,
    pub protocol: Option<String>,
    pub auth: Option<String>,
    pub via: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct Issue {
    /// error | warn
    pub level: &'static str,
    pub target: String,
    pub field: &'static str,
    pub message: String,
}

// ---------- утилиты ----------

pub fn none_if_empty(s: &str) -> Option<String> {
    let t = s.trim();
    if t.is_empty() {
        None
    } else {
        Some(t.to_string())
    }
}

fn fmt_id(prefix: &str, n: u32) -> String {
    format!("{prefix}{n:02}")
}

fn id_num(id: &str) -> u32 {
    id.trim_start_matches(|c: char| !c.is_ascii_digit())
        .parse()
        .unwrap_or(0)
}

fn normalize_color(s: &str) -> Result<String, String> {
    let t = s.trim();
    if t.is_empty() {
        return Ok(String::new());
    }
    let ok = t.len() == 7 && t.starts_with('#') && t[1..].chars().all(|c| c.is_ascii_hexdigit());
    if ok {
        Ok(t.to_ascii_uppercase())
    } else {
        Err(format!("Некорректный цвет {t}, нужен формат #RRGGBB"))
    }
}

fn err_missing(kind: &str, id: &str) -> String {
    format!("{kind} {id} не найден(а)")
}

impl Project {
    pub fn new(id: String, name: String, description: String, now: u64) -> Self {
        Project {
            id,
            name,
            description,
            created_at: now,
            updated_at: now,
            boundaries: Vec::new(),
            elements: Vec::new(),
            flows: Vec::new(),
            counters: Counters::default(),
            doc: Doc::default(),
        }
    }

    /// Чистит документацию от ссылок на удалённые TB / DE / DF.
    pub fn clean_doc(&mut self) {
        let tb: BTreeSet<String> = self.boundaries.iter().map(|b| b.id.clone()).collect();
        let de: BTreeSet<String> = self.elements.iter().map(|e| e.id.clone()).collect();
        let df: BTreeSet<String> = self.flows.iter().map(|f| f.id.clone()).collect();
        self.doc.sanitize(&tb, &de, &df);
    }

    pub fn boundary(&self, id: &str) -> Option<&Boundary> {
        self.boundaries.iter().find(|b| b.id == id)
    }

    pub fn element(&self, id: &str) -> Option<&Element> {
        self.elements.iter().find(|e| e.id == id)
    }

    pub fn flow(&self, id: &str) -> Option<&Flow> {
        self.flows.iter().find(|f| f.id == id)
    }

    pub fn boundary_label(&self, id: &Option<String>) -> String {
        match id {
            Some(id) => match self.boundary(id) {
                Some(b) => format!("{} ({})", b.id, b.name),
                None => id.clone(),
            },
            None => "вне границ".to_string(),
        }
    }

    pub fn element_label(&self, id: &str) -> String {
        match self.element(id) {
            Some(e) => format!("{} ({})", e.id, e.name),
            None => id.to_string(),
        }
    }

    /// Цепочка границ от самой внутренней к внешней.
    pub fn ancestors(&self, tb: &Option<String>) -> Vec<String> {
        let mut out = Vec::new();
        let mut cur = tb.clone();
        while let Some(id) = cur {
            if out.contains(&id) || out.len() > 64 {
                break;
            }
            cur = self.boundary(&id).and_then(|b| b.parent.clone());
            out.push(id);
        }
        out
    }

    /// Какие trust boundaries пересекает поток.
    pub fn crossed(&self, f: &Flow) -> Vec<String> {
        let a = self
            .element(&f.from)
            .map(|e| self.ancestors(&e.boundary))
            .unwrap_or_default();
        let b = self
            .element(&f.to)
            .map(|e| self.ancestors(&e.boundary))
            .unwrap_or_default();
        let mut out: Vec<String> = Vec::new();
        for x in a.iter().chain(b.iter()) {
            if a.contains(x) != b.contains(x) && !out.contains(x) {
                out.push(x.clone());
            }
        }
        // Оба компонента в одной обёртке: у каждого своя рамка, поток её пересекает.
        if let (Some(x), Some(y)) = (a.first(), b.first()) {
            let wrapper = self
                .boundary(x)
                .map_or(false, |t| t.style == BoundaryStyle::Wrapper);
            if x == y && wrapper && !out.contains(x) {
                out.push(x.clone());
            }
        }
        if let Some(v) = &f.via {
            if !out.contains(v) {
                out.push(v.clone());
            }
        }
        out.sort();
        out
    }

    /// true, если `candidate` — это `ancestor` или лежит внутри него.
    fn is_inside(&self, candidate: &str, ancestor: &str) -> bool {
        self.ancestors(&Some(candidate.to_string()))
            .iter()
            .any(|x| x == ancestor)
    }

    fn check_parent(&self, parent: &Option<String>, self_id: Option<&str>) -> Result<(), String> {
        let Some(pid) = parent else {
            return Ok(());
        };
        let pb = self
            .boundary(pid)
            .ok_or_else(|| err_missing("Граница", pid))?;
        match pb.style {
            BoundaryStyle::Line => return Err("Внутрь линии-сети ничего вложить нельзя".into()),
            BoundaryStyle::Wrapper => return Err("Внутрь обёртки нельзя вложить другую границу".into()),
            BoundaryStyle::Zone => {}
        }
        if let Some(sid) = self_id {
            if self.is_inside(pid, sid) {
                return Err("Нельзя вложить границу в саму себя или в свою дочернюю".into());
            }
        }
        Ok(())
    }

    fn check_element_tb(&self, tb: &Option<String>) -> Result<(), String> {
        if let Some(id) = tb {
            let b = self.boundary(id).ok_or_else(|| err_missing("Граница", id))?;
            if b.style == BoundaryStyle::Line {
                return Err(format!(
                    "{id} это линия-сеть, в неё нельзя положить компонент. Укажи её в поле «Через сеть» у потока"
                ));
            }
        }
        Ok(())
    }

    fn check_via(&self, via: &Option<String>) -> Result<(), String> {
        if let Some(id) = via {
            let b = self.boundary(id).ok_or_else(|| err_missing("Граница", id))?;
            if b.style != BoundaryStyle::Line {
                return Err(format!("{id} не линия-сеть. В поле «Через сеть» выбирай границы типа «Линия»"));
            }
        }
        Ok(())
    }

    fn auto_color(&self, style: BoundaryStyle, parent: &Option<String>, self_id: Option<&str>) -> String {
        match style {
            BoundaryStyle::Line => LINE_COLOR.to_string(),
            BoundaryStyle::Wrapper => String::new(),
            BoundaryStyle::Zone if parent.is_some() => String::new(),
            BoundaryStyle::Zone => {
                let used: BTreeSet<String> = self
                    .boundaries
                    .iter()
                    .filter(|b| Some(b.id.as_str()) != self_id)
                    .filter(|b| b.style == BoundaryStyle::Zone && b.parent.is_none())
                    .map(|b| b.color.to_ascii_uppercase())
                    .collect();
                PALETTE
                    .iter()
                    .find(|c| !used.contains(**c))
                    .unwrap_or(&PALETTE[used.len() % PALETTE.len()])
                    .to_string()
            }
        }
    }

    fn resolve_color(
        &self,
        raw: &str,
        style: BoundaryStyle,
        parent: &Option<String>,
        self_id: Option<&str>,
    ) -> Result<String, String> {
        if raw.trim() == "auto" {
            Ok(self.auto_color(style, parent, self_id))
        } else {
            normalize_color(raw)
        }
    }

    // ---------- добавление ----------

    pub fn add_boundary(&mut self, inp: BoundaryInput) -> Result<String, String> {
        let name = inp.name.trim();
        if name.is_empty() {
            return Err("Укажи название границы".into());
        }
        let style = if inp.style.trim().is_empty() {
            BoundaryStyle::Zone
        } else {
            BoundaryStyle::parse(&inp.style).ok_or("Неизвестный тип границы")?
        };
        let parent = if style == BoundaryStyle::Line {
            None
        } else {
            none_if_empty(&inp.parent)
        };
        self.check_parent(&parent, None)?;
        let color = self.resolve_color(&inp.color, style, &parent, None)?;
        self.counters.tb += 1;
        let id = fmt_id("TB", self.counters.tb);
        self.boundaries.push(Boundary {
            id: id.clone(),
            name: name.to_string(),
            style,
            color,
            parent,
            description: inp.description.trim().to_string(),
        });
        Ok(id)
    }

    pub fn add_element(&mut self, inp: ElementInput) -> Result<String, String> {
        let name = inp.name.trim();
        if name.is_empty() {
            return Err("Укажи название компонента".into());
        }
        let kind = ElementKind::parse(&inp.kind).ok_or("Выбери тип компонента")?;
        let boundary = none_if_empty(&inp.boundary);
        self.check_element_tb(&boundary)?;
        self.counters.de += 1;
        let id = fmt_id("DE", self.counters.de);
        self.elements.push(Element {
            id: id.clone(),
            name: name.to_string(),
            kind,
            tech: inp.tech.trim().to_string(),
            boundary,
            description: inp.description.trim().to_string(),
        });
        Ok(id)
    }

    pub fn add_flow(&mut self, inp: FlowInput) -> Result<String, String> {
        let from = inp.from.trim();
        let to = inp.to.trim();
        if from.is_empty() || to.is_empty() {
            return Err("Выбери, откуда и куда идёт поток".into());
        }
        if from == to {
            return Err("Поток не может идти в тот же компонент".into());
        }
        if self.element(from).is_none() || self.element(to).is_none() {
            return Err("Компонент не найден".into());
        }
        let via = none_if_empty(&inp.via);
        self.check_via(&via)?;
        self.counters.df += 1;
        let id = fmt_id("DF", self.counters.df);
        self.flows.push(Flow {
            id: id.clone(),
            from: from.to_string(),
            to: to.to_string(),
            title: inp.title.trim().to_string(),
            data: none_if_empty(&inp.data),
            protocol: none_if_empty(&inp.protocol),
            auth: none_if_empty(&inp.auth),
            via,
            notes: inp.notes.trim().to_string(),
        });
        Ok(id)
    }

    // ---------- редактирование ----------

    pub fn update_boundary(&mut self, id: &str, patch: BoundaryPatch) -> Result<(), String> {
        let cur = self
            .boundary(id)
            .ok_or_else(|| err_missing("Граница", id))?
            .clone();
        let style = match &patch.style {
            Some(s) => BoundaryStyle::parse(s).ok_or("Неизвестный тип границы")?,
            None => cur.style,
        };
        let parent = match &patch.parent {
            Some(s) => none_if_empty(s),
            None => cur.parent.clone(),
        };
        let parent = if style == BoundaryStyle::Line { None } else { parent };
        self.check_parent(&parent, Some(id))?;

        let has_children = self.boundaries.iter().any(|b| b.parent.as_deref() == Some(id));
        let has_members = self.elements.iter().any(|e| e.boundary.as_deref() == Some(id));
        if style == BoundaryStyle::Line && (has_children || has_members) {
            return Err("Чтобы сделать границу линией, сначала убери из неё компоненты и вложенные границы".into());
        }
        if style == BoundaryStyle::Wrapper && has_children {
            return Err("У обёртки не может быть вложенных границ".into());
        }

        let name = match patch.name {
            Some(n) => {
                let n = n.trim().to_string();
                if n.is_empty() {
                    return Err("Название не может быть пустым".into());
                }
                n
            }
            None => cur.name.clone(),
        };
        let color = match &patch.color {
            Some(c) => self.resolve_color(c, style, &parent, Some(id))?,
            None if style != cur.style => self.auto_color(style, &parent, Some(id)),
            None => cur.color.clone(),
        };
        let description = patch
            .description
            .map(|d| d.trim().to_string())
            .unwrap_or(cur.description);

        if cur.style == BoundaryStyle::Line && style != BoundaryStyle::Line {
            for f in &mut self.flows {
                if f.via.as_deref() == Some(id) {
                    f.via = None;
                }
            }
        }
        let b = self
            .boundaries
            .iter_mut()
            .find(|b| b.id == id)
            .ok_or("Граница не найдена")?;
        b.name = name;
        b.style = style;
        b.parent = parent;
        b.color = color;
        b.description = description;
        Ok(())
    }

    pub fn update_element(&mut self, id: &str, patch: ElementPatch) -> Result<(), String> {
        let kind = match &patch.kind {
            Some(k) => Some(ElementKind::parse(k).ok_or("Неизвестный тип компонента")?),
            None => None,
        };
        let boundary = patch.boundary.as_deref().map(none_if_empty);
        if let Some(b) = &boundary {
            self.check_element_tb(b)?;
        }
        if let Some(n) = &patch.name {
            if n.trim().is_empty() {
                return Err("Название не может быть пустым".into());
            }
        }
        let e = self
            .elements
            .iter_mut()
            .find(|e| e.id == id)
            .ok_or_else(|| err_missing("Компонент", id))?;
        if let Some(n) = patch.name {
            e.name = n.trim().to_string();
        }
        if let Some(k) = kind {
            e.kind = k;
        }
        if let Some(t) = patch.tech {
            e.tech = t.trim().to_string();
        }
        if let Some(b) = boundary {
            e.boundary = b;
        }
        if let Some(d) = patch.description {
            e.description = d.trim().to_string();
        }
        Ok(())
    }

    pub fn update_flow(&mut self, id: &str, patch: FlowPatch) -> Result<(), String> {
        let cur = self.flow(id).ok_or_else(|| err_missing("Поток", id))?.clone();
        let from = patch.from.clone().unwrap_or(cur.from);
        let to = patch.to.clone().unwrap_or(cur.to);
        if from == to {
            return Err("Поток не может идти в тот же компонент".into());
        }
        if self.element(&from).is_none() || self.element(&to).is_none() {
            return Err("Компонент не найден".into());
        }
        let via = match &patch.via {
            Some(v) => none_if_empty(v),
            None => cur.via,
        };
        self.check_via(&via)?;
        let f = self
            .flows
            .iter_mut()
            .find(|f| f.id == id)
            .ok_or("Поток не найден")?;
        f.from = from;
        f.to = to;
        f.via = via;
        if let Some(v) = patch.title {
            f.title = v.trim().to_string();
        }
        if let Some(v) = patch.data {
            f.data = none_if_empty(&v);
        }
        if let Some(v) = patch.protocol {
            f.protocol = none_if_empty(&v);
        }
        if let Some(v) = patch.auth {
            f.auth = none_if_empty(&v);
        }
        if let Some(v) = patch.notes {
            f.notes = v.trim().to_string();
        }
        Ok(())
    }

    // ---------- удаление ----------

    /// Содержимое удалённой границы поднимается на уровень выше.
    pub fn delete_boundary(&mut self, id: &str) -> Result<(), String> {
        let parent = self
            .boundary(id)
            .ok_or_else(|| err_missing("Граница", id))?
            .parent
            .clone();
        for b in &mut self.boundaries {
            if b.parent.as_deref() == Some(id) {
                b.parent = parent.clone();
            }
        }
        for e in &mut self.elements {
            if e.boundary.as_deref() == Some(id) {
                e.boundary = parent.clone();
            }
        }
        for f in &mut self.flows {
            if f.via.as_deref() == Some(id) {
                f.via = None;
            }
        }
        self.boundaries.retain(|b| b.id != id);
        Ok(())
    }

    /// Удаляет компонент и все его потоки.
    pub fn delete_element(&mut self, id: &str) -> Result<(), String> {
        if self.element(id).is_none() {
            return Err(err_missing("Компонент", id));
        }
        self.elements.retain(|e| e.id != id);
        self.flows.retain(|f| f.from != id && f.to != id);
        Ok(())
    }

    pub fn delete_flow(&mut self, id: &str) -> Result<(), String> {
        if self.flow(id).is_none() {
            return Err(err_missing("Поток", id));
        }
        self.flows.retain(|f| f.id != id);
        Ok(())
    }

    // ---------- проверка полноты ----------

    pub fn issues(&self) -> Vec<Issue> {
        let mut out = Vec::new();
        let mut push = |level: &'static str, target: &str, field: &'static str, message: String| {
            out.push(Issue {
                level,
                target: target.to_string(),
                field,
                message,
            })
        };

        if self.elements.is_empty() {
            push("error", "", "", "Добавь хотя бы один компонент (DE)".into());
        }
        for f in &self.flows {
            if f.title.trim().is_empty() {
                push("error", &f.id, "title", format!("{}: укажи назначение потока (например, Login)", f.id));
            }
            if f.protocol.is_none() {
                push("error", &f.id, "protocol", format!("{}: укажи протокол", f.id));
            }
            if f.auth.is_none() && !self.crossed(f).is_empty() {
                push("warn", &f.id, "auth", format!("{}: пересекает границы, но аутентификация не указана", f.id));
            }
            if f.data.is_none() {
                push("warn", &f.id, "data", format!("{}: не указано, какие данные передаются", f.id));
            }
        }
        if !self.boundaries.is_empty() {
            for e in &self.elements {
                if e.boundary.is_none() {
                    push("warn", &e.id, "boundary", format!("{}: компонент вне всех границ", e.id));
                }
            }
        }
        for b in &self.boundaries {
            match b.style {
                BoundaryStyle::Line => {
                    if !self.flows.iter().any(|f| f.via.as_deref() == Some(b.id.as_str())) {
                        push(
                            "warn",
                            &b.id,
                            "style",
                            format!("{}: линия не указана ни в одном потоке (поле «Через сеть»), на диаграмме её не будет", b.id),
                        );
                    }
                }
                _ => {
                    let has_members = self.elements.iter().any(|e| {
                        self.ancestors(&e.boundary).iter().any(|x| *x == b.id)
                    });
                    if !has_members {
                        push("warn", &b.id, "name", format!("{}: в границе нет компонентов, на диаграмме её не будет", b.id));
                    }
                }
            }
        }
        out
    }

    // ---------- служебное ----------

    pub fn fix_counters(&mut self) {
        let max_tb = self.boundaries.iter().map(|b| id_num(&b.id)).max().unwrap_or(0);
        let max_de = self.elements.iter().map(|e| id_num(&e.id)).max().unwrap_or(0);
        let max_df = self.flows.iter().map(|f| id_num(&f.id)).max().unwrap_or(0);
        self.counters.tb = self.counters.tb.max(max_tb);
        self.counters.de = self.counters.de.max(max_de);
        self.counters.df = self.counters.df.max(max_df);
    }

    /// После импорта: убираем битые ссылки и недопустимые вложения.
    pub fn sanitize(&mut self) {
        let snapshot = self.boundaries.clone();
        let find = |id: &str| snapshot.iter().find(|b| b.id == id);
        for b in &mut self.boundaries {
            if b.style == BoundaryStyle::Line {
                b.parent = None;
            }
            let bad = b.parent.as_deref().map_or(false, |p| {
                *p == b.id || find(p).map_or(true, |pb| pb.style != BoundaryStyle::Zone)
            });
            if bad {
                b.parent = None;
            }
            if normalize_color(&b.color).is_err() {
                b.color = String::new();
            }
        }
        for e in &mut self.elements {
            let bad = e.boundary.as_deref().map_or(false, |x| {
                find(x).map_or(true, |b| b.style == BoundaryStyle::Line)
            });
            if bad {
                e.boundary = None;
            }
        }
        let de_ids: BTreeSet<String> = self.elements.iter().map(|e| e.id.clone()).collect();
        self.flows
            .retain(|f| de_ids.contains(&f.from) && de_ids.contains(&f.to) && f.from != f.to);
        for f in &mut self.flows {
            let bad = f.via.as_deref().map_or(false, |x| {
                find(x).map_or(true, |b| b.style != BoundaryStyle::Line)
            });
            if bad {
                f.via = None;
            }
        }
    }
}
