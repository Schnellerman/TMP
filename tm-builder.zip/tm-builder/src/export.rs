//! Таблицы DE / DF / TB, Agenda и Markdown-отчёт.
//! Диаграмму раскладывает и рисует браузер (ELK + SVG / draw.io).

use crate::model::Project;
use serde::Serialize;

#[derive(Debug, Clone, Serialize)]
pub struct Table {
    pub key: &'static str,
    pub title: String,
    pub headers: Vec<String>,
    pub rows: Vec<Vec<String>>,
    /// Цвет первой ячейки строки ("#RRGGBB" или пусто).
    pub row_colors: Vec<String>,
}

fn dash(s: &str) -> String {
    if s.trim().is_empty() {
        "—".into()
    } else {
        s.trim().to_string()
    }
}

fn opt(o: &Option<String>) -> String {
    o.as_deref().map(dash).unwrap_or_else(|| "—".into())
}

fn hdr(h: &[&str]) -> Vec<String> {
    h.iter().map(|s| s.to_string()).collect()
}

/// Текст строки DF в Agenda: «HTTPS Login».
pub fn flow_caption(protocol: &Option<String>, title: &str) -> String {
    let parts: Vec<&str> = [protocol.as_deref().unwrap_or(""), title.trim()]
        .into_iter()
        .filter(|s| !s.trim().is_empty())
        .collect();
    if parts.is_empty() {
        "—".into()
    } else {
        parts.join(" ")
    }
}

pub fn agenda(p: &Project) -> Table {
    let mut boundaries: Vec<_> = p.boundaries.iter().collect();
    boundaries.sort_by(|a, b| a.id.cmp(&b.id));
    let mut rows = Vec::new();
    let mut row_colors = Vec::new();
    for b in boundaries {
        rows.push(vec![b.id.clone(), b.name.clone()]);
        row_colors.push(b.color.clone());
    }
    for f in &p.flows {
        rows.push(vec![f.id.clone(), flow_caption(&f.protocol, &f.title)]);
        row_colors.push(String::new());
    }
    Table {
        key: "agenda",
        title: "Agenda".into(),
        headers: hdr(&["ID", "Описание"]),
        rows,
        row_colors,
    }
}

pub fn tables(p: &Project) -> Vec<Table> {
    let de_rows: Vec<Vec<String>> = p
        .elements
        .iter()
        .map(|e| {
            vec![
                e.id.clone(),
                e.name.clone(),
                e.kind.label().to_string(),
                dash(&e.tech),
                p.boundary_label(&e.boundary),
                dash(&e.description),
            ]
        })
        .collect();

    let df_rows: Vec<Vec<String>> = p
        .flows
        .iter()
        .map(|f| {
            let crossed = p.crossed(f);
            vec![
                f.id.clone(),
                p.element_label(&f.from),
                p.element_label(&f.to),
                dash(&f.title),
                opt(&f.protocol),
                opt(&f.auth),
                opt(&f.data),
                f.via.as_ref().map(|v| p.boundary_label(&Some(v.clone()))).unwrap_or_else(|| "—".into()),
                if crossed.is_empty() { "—".into() } else { crossed.join(", ") },
                dash(&f.notes),
            ]
        })
        .collect();

    let tb_rows: Vec<Vec<String>> = p
        .boundaries
        .iter()
        .map(|b| {
            let comps: Vec<String> = p
                .elements
                .iter()
                .filter(|e| e.boundary.as_deref() == Some(b.id.as_str()))
                .map(|e| format!("{} ({})", e.id, e.name))
                .collect();
            vec![
                b.id.clone(),
                b.name.clone(),
                b.style.label().to_string(),
                match &b.parent {
                    Some(_) => p.boundary_label(&b.parent),
                    None => "—".into(),
                },
                if comps.is_empty() { "—".into() } else { comps.join(", ") },
                dash(&b.description),
            ]
        })
        .collect();
    let tb_colors = p.boundaries.iter().map(|b| b.color.clone()).collect();

    vec![
        agenda(p),
        Table {
            key: "elements",
            title: "Компоненты (DE)".into(),
            headers: hdr(&["ID", "Название", "Тип", "Технология", "Trust boundary", "Описание"]),
            row_colors: vec![String::new(); de_rows.len()],
            rows: de_rows,
        },
        Table {
            key: "flows",
            title: "Потоки данных (DF)".into(),
            headers: hdr(&[
                "ID",
                "Откуда",
                "Куда",
                "Назначение",
                "Протокол",
                "Аутентификация",
                "Данные",
                "Через сеть",
                "Пересекает TB",
                "Заметки",
            ]),
            row_colors: vec![String::new(); df_rows.len()],
            rows: df_rows,
        },
        Table {
            key: "boundaries",
            title: "Trust boundaries (TB)".into(),
            headers: hdr(&["ID", "Название", "Тип", "Находится внутри", "Компоненты (DE)", "Описание"]),
            rows: tb_rows,
            row_colors: tb_colors,
        },
    ]
}

fn md_cell(c: &str) -> String {
    c.replace('|', "\\|").replace('\n', " ")
}

pub fn md_table(t: &Table) -> String {
    let mut s = String::new();
    let head: Vec<String> = t.headers.iter().map(|h| md_cell(h)).collect();
    s.push_str(&format!("| {} |\n", head.join(" | ")));
    s.push_str(&format!("|{}\n", " --- |".repeat(t.headers.len())));
    for r in &t.rows {
        let cells: Vec<String> = r.iter().map(|c| md_cell(c)).collect();
        s.push_str(&format!("| {} |\n", cells.join(" | ")));
    }
    s
}

pub fn markdown(p: &Project) -> String {
    let mut s = format!("# Модель угроз: {}\n\n", p.name);
    if !p.description.trim().is_empty() {
        s.push_str(p.description.trim());
        s.push_str("\n\n");
    }
    s.push_str("## Архитектурная диаграмма\n\n_Вставь сюда PNG или SVG из TM Builder._\n\n");
    for t in tables(p) {
        s.push_str(&format!("## {}\n\n{}\n", t.title, md_table(&t)));
    }
    s
}
