mod doc;
mod export;
mod model;

use axum::{
    extract::{Path, State},
    http::{header, StatusCode},
    response::{Html, IntoResponse, Response},
    routing::{get, post, put},
    Json, Router,
};
use model::{
    BoundaryInput, BoundaryPatch, BoundaryStyle, ElementInput, ElementKind, ElementPatch, FlowInput,
    FlowPatch, Issue, Project,
};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, HashMap},
    path::PathBuf,
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};
use tokio::sync::Mutex;

const INDEX_HTML: &str = include_str!("../static/index.html");

struct AppState {
    dir: PathBuf,
    projects: Mutex<HashMap<String, Project>>,
}

impl AppState {
    fn save(&self, p: &Project) -> std::io::Result<()> {
        let path = self.dir.join(format!("{}.json", p.id));
        let tmp = self.dir.join(format!("{}.json.tmp", p.id));
        let data = serde_json::to_vec_pretty(p)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
        std::fs::write(&tmp, data)?;
        std::fs::rename(&tmp, &path)
    }

    fn remove(&self, id: &str) -> std::io::Result<()> {
        let path = self.dir.join(format!("{id}.json"));
        if path.exists() {
            std::fs::remove_file(path)?;
        }
        Ok(())
    }
}

fn load_all(dir: &PathBuf) -> HashMap<String, Project> {
    let mut map = HashMap::new();
    let Ok(rd) = std::fs::read_dir(dir) else {
        return map;
    };
    for entry in rd.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("json") {
            continue;
        }
        let parsed = std::fs::read(&path)
            .map_err(|e| e.to_string())
            .and_then(|b| serde_json::from_slice::<Project>(&b).map_err(|e| e.to_string()));
        match parsed {
            Ok(mut p) => {
                p.fix_counters();
                map.insert(p.id.clone(), p);
            }
            Err(e) => eprintln!("Пропускаю {}: {e}", path.display()),
        }
    }
    map
}

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0)
}

fn new_id() -> String {
    let n = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    format!("p{n:x}")
}

// ---------- ошибки ----------

struct ApiError(StatusCode, String);

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (self.0, Json(serde_json::json!({ "error": self.1 }))).into_response()
    }
}

fn bad(msg: String) -> ApiError {
    ApiError(StatusCode::BAD_REQUEST, msg)
}

fn not_found() -> ApiError {
    ApiError(StatusCode::NOT_FOUND, "Модель не найдена".into())
}

fn internal<E: std::fmt::Display>(e: E) -> ApiError {
    eprintln!("Ошибка: {e}");
    ApiError(StatusCode::INTERNAL_SERVER_ERROR, format!("Ошибка сервера: {e}"))
}

type ApiResult<T> = Result<T, ApiError>;

// ---------- ответ со всем состоянием модели ----------

#[derive(Serialize)]
struct Opt {
    value: String,
    label: String,
}

#[derive(Serialize)]
struct Bundle {
    project: Project,
    tables: Vec<export::Table>,
    markdown: String,
    kinds: Vec<Opt>,
    styles: Vec<Opt>,
    issues: Vec<Issue>,
    crossed: BTreeMap<String, Vec<String>>,
}

fn bundle(p: &Project) -> Bundle {
    Bundle {
        project: p.clone(),
        tables: export::tables(p),
        markdown: export::markdown(p),
        kinds: ElementKind::ALL
            .iter()
            .map(|k| Opt {
                value: k.code().to_string(),
                label: k.label().to_string(),
            })
            .collect(),
        styles: BoundaryStyle::ALL
            .iter()
            .map(|k| Opt {
                value: k.code().to_string(),
                label: k.label().to_string(),
            })
            .collect(),
        issues: p.issues(),
        crossed: p.flows.iter().map(|f| (f.id.clone(), p.crossed(f))).collect(),
    }
}

/// Применяет изменение к копии модели; при ошибке исходная модель не меняется.
async fn mutate(
    st: &AppState,
    id: &str,
    f: impl FnOnce(&mut Project) -> Result<(), String>,
) -> ApiResult<Json<Bundle>> {
    let mut map = st.projects.lock().await;
    let p = map.get_mut(id).ok_or_else(not_found)?;
    let mut draft = p.clone();
    f(&mut draft).map_err(bad)?;
    draft.clean_doc();
    draft.updated_at = now();
    st.save(&draft).map_err(internal)?;
    *p = draft;
    Ok(Json(bundle(p)))
}

// ---------- хендлеры ----------

async fn index() -> Html<&'static str> {
    Html(INDEX_HTML)
}

/// Опционально: положи elk.bundled.js в static/ для работы без интернета.
async fn vendor(Path(file): Path<String>) -> Response {
    if file != "elk.bundled.js" {
        return StatusCode::NOT_FOUND.into_response();
    }
    let dir = std::env::var("STATIC_DIR").unwrap_or_else(|_| "static".into());
    match std::fs::read(PathBuf::from(dir).join(&file)) {
        Ok(b) => (
            [(header::CONTENT_TYPE, "application/javascript; charset=utf-8")],
            b,
        )
            .into_response(),
        Err(_) => StatusCode::NOT_FOUND.into_response(),
    }
}

#[derive(Serialize)]
struct Summary {
    id: String,
    name: String,
    description: String,
    updated_at: u64,
    elements: usize,
    flows: usize,
    boundaries: usize,
    done: bool,
}

async fn list_projects(State(st): State<Arc<AppState>>) -> Json<Vec<Summary>> {
    let map = st.projects.lock().await;
    let mut v: Vec<Summary> = map
        .values()
        .map(|p| Summary {
            id: p.id.clone(),
            name: p.name.clone(),
            description: p.description.clone(),
            updated_at: p.updated_at,
            elements: p.elements.len(),
            flows: p.flows.len(),
            boundaries: p.boundaries.len(),
            done: !p.issues().iter().any(|i| i.level == "error"),
        })
        .collect();
    v.sort_by(|a, b| b.updated_at.cmp(&a.updated_at));
    Json(v)
}

#[derive(Deserialize)]
struct NewProject {
    name: String,
    #[serde(default)]
    description: String,
}

async fn create_project(
    State(st): State<Arc<AppState>>,
    Json(req): Json<NewProject>,
) -> ApiResult<Json<Bundle>> {
    let name = req.name.trim();
    if name.is_empty() {
        return Err(bad("Укажи название модели".into()));
    }
    let p = Project::new(
        new_id(),
        name.to_string(),
        req.description.trim().to_string(),
        now(),
    );
    st.save(&p).map_err(internal)?;
    let b = bundle(&p);
    st.projects.lock().await.insert(p.id.clone(), p);
    Ok(Json(b))
}

async fn import_project(
    State(st): State<Arc<AppState>>,
    Json(mut p): Json<Project>,
) -> ApiResult<Json<Bundle>> {
    p.id = new_id();
    p.updated_at = now();
    if p.created_at == 0 {
        p.created_at = p.updated_at;
    }
    if p.name.trim().is_empty() {
        p.name = "Импортированная модель".into();
    }
    p.sanitize();
    p.fix_counters();
    p.clean_doc();
    st.save(&p).map_err(internal)?;
    let b = bundle(&p);
    st.projects.lock().await.insert(p.id.clone(), p);
    Ok(Json(b))
}

async fn get_project(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
) -> ApiResult<Json<Bundle>> {
    let map = st.projects.lock().await;
    let p = map.get(&id).ok_or_else(not_found)?;
    Ok(Json(bundle(p)))
}

#[derive(Deserialize)]
struct MetaPatch {
    name: Option<String>,
    description: Option<String>,
}

async fn update_project(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
    Json(m): Json<MetaPatch>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| {
        if let Some(n) = m.name {
            let n = n.trim();
            if n.is_empty() {
                return Err("Название не может быть пустым".into());
            }
            p.name = n.to_string();
        }
        if let Some(d) = m.description {
            p.description = d.trim().to_string();
        }
        Ok(())
    })
    .await
}

async fn update_doc(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
    Json(doc): Json<doc::Doc>,
) -> ApiResult<Json<serde_json::Value>> {
    let mut map = st.projects.lock().await;
    let p = map.get_mut(&id).ok_or_else(not_found)?;
    let mut draft = p.clone();
    draft.doc = doc;
    draft.clean_doc();
    draft.updated_at = now();
    st.save(&draft).map_err(internal)?;
    let out = serde_json::json!({ "updated_at": draft.updated_at, "doc": draft.doc });
    *p = draft;
    Ok(Json(out))
}

async fn delete_project(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
) -> ApiResult<StatusCode> {
    let mut map = st.projects.lock().await;
    if map.remove(&id).is_none() {
        return Err(not_found());
    }
    st.remove(&id).map_err(internal)?;
    Ok(StatusCode::NO_CONTENT)
}

async fn create_boundary(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
    Json(inp): Json<BoundaryInput>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.add_boundary(inp).map(|_| ())).await
}

async fn create_element(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
    Json(inp): Json<ElementInput>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.add_element(inp).map(|_| ())).await
}

async fn create_flow(
    State(st): State<Arc<AppState>>,
    Path(id): Path<String>,
    Json(inp): Json<FlowInput>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.add_flow(inp).map(|_| ())).await
}

async fn update_element(
    State(st): State<Arc<AppState>>,
    Path((id, eid)): Path<(String, String)>,
    Json(patch): Json<ElementPatch>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.update_element(&eid, patch)).await
}

async fn delete_element(
    State(st): State<Arc<AppState>>,
    Path((id, eid)): Path<(String, String)>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.delete_element(&eid)).await
}

async fn update_flow(
    State(st): State<Arc<AppState>>,
    Path((id, fid)): Path<(String, String)>,
    Json(patch): Json<FlowPatch>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.update_flow(&fid, patch)).await
}

async fn delete_flow(
    State(st): State<Arc<AppState>>,
    Path((id, fid)): Path<(String, String)>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.delete_flow(&fid)).await
}

async fn update_boundary(
    State(st): State<Arc<AppState>>,
    Path((id, bid)): Path<(String, String)>,
    Json(patch): Json<BoundaryPatch>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.update_boundary(&bid, patch)).await
}

async fn delete_boundary(
    State(st): State<Arc<AppState>>,
    Path((id, bid)): Path<(String, String)>,
) -> ApiResult<Json<Bundle>> {
    mutate(&st, &id, move |p| p.delete_boundary(&bid)).await
}

#[tokio::main]
async fn main() {
    let dir = PathBuf::from(std::env::var("DATA_DIR").unwrap_or_else(|_| "data".into()));
    if let Err(e) = std::fs::create_dir_all(&dir) {
        eprintln!("Не удалось создать каталог данных {}: {e}", dir.display());
        std::process::exit(1);
    }
    let projects = load_all(&dir);
    let loaded = projects.len();
    let state = Arc::new(AppState {
        dir: dir.clone(),
        projects: Mutex::new(projects),
    });

    let app = Router::new()
        .route("/", get(index))
        .route("/vendor/:file", get(vendor))
        .route("/api/projects", get(list_projects).post(create_project))
        .route("/api/projects/import", post(import_project))
        .route(
            "/api/projects/:id",
            get(get_project).put(update_project).delete(delete_project),
        )
        .route("/api/projects/:id/doc", put(update_doc))
        .route("/api/projects/:id/boundaries", post(create_boundary))
        .route("/api/projects/:id/elements", post(create_element))
        .route("/api/projects/:id/flows", post(create_flow))
        .route(
            "/api/projects/:id/elements/:eid",
            put(update_element).delete(delete_element),
        )
        .route(
            "/api/projects/:id/flows/:fid",
            put(update_flow).delete(delete_flow),
        )
        .route(
            "/api/projects/:id/boundaries/:bid",
            put(update_boundary).delete(delete_boundary),
        )
        .with_state(state);

    let addr = std::env::var("BIND").unwrap_or_else(|_| "127.0.0.1:8080".into());
    let listener = match tokio::net::TcpListener::bind(&addr).await {
        Ok(l) => l,
        Err(e) => {
            eprintln!("Не удалось занять {addr}: {e}");
            std::process::exit(1);
        }
    };
    println!(
        "TM Builder запущен: http://{addr}  (данные: {}, моделей: {loaded})",
        dir.display()
    );
    if let Err(e) = axum::serve(listener, app).await {
        eprintln!("Сервер остановлен с ошибкой: {e}");
    }
}
