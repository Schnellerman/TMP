//! Документация для отчёта: overview, use cases, data assets, attacker profiles,
//! access control matrices и данные раздела Threat Modeling.

use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

pub const CONFIDENTIALITY: [&str; 4] = ["Strictly Confidential", "Restricted", "Internal", "Public"];
pub const LEVELS: [&str; 4] = ["Critical", "High", "Medium", "Low"];
pub const LIKELIHOOD: [&str; 4] = ["Very Likely", "Likely", "Possible", "Unlikely"];
pub const UC_ACCESS: [&str; 2] = ["Has access", "No access"];
pub const DA_ACCESS: [&str; 7] = [
    "Read only",
    "Write only",
    "Read/Write",
    "Read only own",
    "Write only own",
    "Read/Write own",
    "No access",
];
pub const STRIDE: [&str; 6] = [
    "Spoofing",
    "Tampering",
    "Repudiation",
    "Information Disclosure",
    "Denial of Service",
    "Elevation of Privilege",
];

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct UseCase {
    pub id: String,
    pub name: String,
    pub description: String,
    pub data: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct DataAsset {
    pub id: String,
    pub name: String,
    pub description: String,
    pub confidentiality: String,
    pub integrity: String,
    pub availability: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct Attacker {
    pub id: String,
    pub name: String,
    pub description: String,
    pub motive: String,
    pub likelihood: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct ChecklistRow {
    pub category: String,
    pub threat: String,
    pub mitigation: String,
    pub verification: String,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct ChecklistBlock {
    /// ID компонента (DE).
    pub element: String,
    pub rows: Vec<ChecklistRow>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct Doc {
    // Application Overview
    pub description: String,
    pub env_links: String,
    pub repository: String,
    // Таблицы
    pub use_cases: Vec<UseCase>,
    pub data_assets: Vec<DataAsset>,
    pub attackers: Vec<Attacker>,
    /// attacker id → use case id → "Has access" | "No access"
    pub acl_uc: BTreeMap<String, BTreeMap<String, String>>,
    /// attacker id → data asset id → уровень доступа
    pub acl_da: BTreeMap<String, BTreeMap<String, String>>,
    // Threat Modeling
    pub diagram_description: String,
    /// TB id → attacker ids
    pub tb_attackers: BTreeMap<String, Vec<String>>,
    /// DF id → Security Control
    pub df_controls: BTreeMap<String, String>,
    pub checklist_note: String,
    pub checklist: Vec<ChecklistBlock>,
}

trait HasId {
    fn id_mut(&mut self) -> &mut String;
}
impl HasId for UseCase {
    fn id_mut(&mut self) -> &mut String {
        &mut self.id
    }
}
impl HasId for DataAsset {
    fn id_mut(&mut self) -> &mut String {
        &mut self.id
    }
}
impl HasId for Attacker {
    fn id_mut(&mut self) -> &mut String {
        &mut self.id
    }
}

/// Гарантирует непустые и уникальные ID.
fn fix_ids<T: HasId>(items: &mut [T], prefix: &str) -> BTreeSet<String> {
    let mut seen = BTreeSet::new();
    let mut n = 0u32;
    for it in items.iter_mut() {
        let id = it.id_mut();
        if id.trim().is_empty() || seen.contains(id.as_str()) {
            loop {
                n += 1;
                let candidate = format!("{prefix}{n}");
                if !seen.contains(&candidate) {
                    *id = candidate;
                    break;
                }
            }
        }
        seen.insert(id.clone());
    }
    seen
}

fn keep(v: &mut String, allowed: &[&str]) {
    if !allowed.contains(&v.as_str()) {
        v.clear();
    }
}

impl Doc {
    /// Убирает ссылки на удалённые объекты и недопустимые значения.
    pub fn sanitize(&mut self, tb_ids: &BTreeSet<String>, de_ids: &BTreeSet<String>, df_ids: &BTreeSet<String>) {
        let uc = fix_ids(&mut self.use_cases, "uc");
        let da = fix_ids(&mut self.data_assets, "da");
        let ap = fix_ids(&mut self.attackers, "ap");

        for x in &mut self.data_assets {
            keep(&mut x.confidentiality, &CONFIDENTIALITY);
            keep(&mut x.integrity, &LEVELS);
            keep(&mut x.availability, &LEVELS);
        }
        for x in &mut self.attackers {
            keep(&mut x.likelihood, &LIKELIHOOD);
        }

        self.acl_uc.retain(|k, _| ap.contains(k));
        for m in self.acl_uc.values_mut() {
            m.retain(|k, v| uc.contains(k) && UC_ACCESS.contains(&v.as_str()));
        }
        self.acl_da.retain(|k, _| ap.contains(k));
        for m in self.acl_da.values_mut() {
            m.retain(|k, v| da.contains(k) && DA_ACCESS.contains(&v.as_str()));
        }

        self.tb_attackers.retain(|k, _| tb_ids.contains(k));
        for v in self.tb_attackers.values_mut() {
            let mut seen = BTreeSet::new();
            v.retain(|a| ap.contains(a) && seen.insert(a.clone()));
        }
        self.df_controls.retain(|k, _| df_ids.contains(k));

        let mut seen = BTreeSet::new();
        self.checklist
            .retain(|b| de_ids.contains(&b.element) && seen.insert(b.element.clone()));
        for b in &mut self.checklist {
            for r in &mut b.rows {
                if !STRIDE.contains(&r.category.as_str()) {
                    r.category = STRIDE[0].to_string();
                }
            }
        }
    }
}
